const express = require("express");
const bcrypt = require("bcryptjs");
const { z } = require("zod");
const prisma = require("../db");
const { createSession, setSessionCookie, clearSessionCookie, requireAuth, COOKIE_NAME } = require("../middleware/auth");
const { authLimiter } = require("../middleware/rateLimit");
const { logAudit } = require("../lib/audit");

const router = express.Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8, "رمز عبور باید حداقل 8 کاراکتر باشد"),
  name: z.string().min(1).max(120).optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post("/register", authLimiter, async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0]?.message || "ورودی نامعتبر است" });
  }
  const { email, password, name } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return res.status(409).json({ error: "این ایمیل قبلا ثبت‌نام کرده است" });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const result = await prisma.$transaction(async (tx) => {
    const freePlan = await tx.plan.findUnique({ where: { name: "Free" } });
    const workspace = await tx.workspace.create({
      data: { name: `${name || email.split("@")[0]}'s Workspace`, planId: freePlan?.id },
    });
    const user = await tx.user.create({
      data: { email, passwordHash, name, workspaceId: workspace.id, role: "USER" },
    });
    return { user, workspace };
  });

  const token = await createSession(result.user, req);
  setSessionCookie(res, token);
  await logAudit({ workspaceId: result.workspace.id, userId: result.user.id, action: "Login", metadata: { via: "register" }, ip: req.ip });

  res.status(201).json({
    user: { id: result.user.id, email: result.user.email, name: result.user.name, role: result.user.role },
    workspaceId: result.workspace.id,
  });
});

router.post("/login", authLimiter, async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "ایمیل یا رمز عبور نامعتبر است" });
  }
  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });
  // پیام یکسان برای جلوگیری از User Enumeration
  const genericError = { error: "ایمیل یا رمز عبور اشتباه است" };
  if (!user) return res.status(401).json(genericError);

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) return res.status(401).json(genericError);

  if (user.status !== "ACTIVE") {
    return res.status(403).json({ error: "حساب کاربری غیرفعال شده است" });
  }

  const token = await createSession(user, req);
  setSessionCookie(res, token);
  await prisma.user.update({ where: { id: user.id }, data: { lastSeen: new Date() } });
  await logAudit({ workspaceId: user.workspaceId, userId: user.id, action: "Login", ip: req.ip });

  res.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role }, workspaceId: user.workspaceId });
});

router.post("/logout", requireAuth, async (req, res) => {
  const { sha256 } = require("../lib/crypto");
  await prisma.session.deleteMany({ where: { tokenHash: sha256(req.sessionToken) } }).catch(() => {});
  clearSessionCookie(res);
  await logAudit({ workspaceId: req.user.workspaceId, userId: req.user.id, action: "Logout", ip: req.ip });
  res.json({ ok: true });
});

router.get("/me", requireAuth, async (req, res) => {
  res.json({
    user: {
      id: req.user.id,
      email: req.user.email,
      name: req.user.name,
      role: req.user.role,
      workspaceId: req.user.workspaceId,
    },
  });
});

module.exports = router;
