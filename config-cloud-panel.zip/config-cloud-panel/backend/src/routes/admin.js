const express = require("express");
const { z } = require("zod");
const prisma = require("../db");
const { requireAuth, requireAdmin } = require("../middleware/auth");
const { adminLimiter } = require("../middleware/rateLimit");
const { logAudit } = require("../lib/audit");

const router = express.Router();
router.use(requireAuth, requireAdmin, adminLimiter);

router.get("/stats", async (req, res) => {
  const [totalUsers, activeUsers, totalWorkspaces, totalConfigs, activeConfigs] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { status: "ACTIVE" } }),
    prisma.workspace.count(),
    prisma.config.count(),
    prisma.config.count({ where: { status: "ACTIVE" } }),
  ]);
  const trafficAgg = await prisma.config.aggregate({ _sum: { trafficUsedBytes: true } });

  res.json({
    totalUsers,
    activeUsers,
    totalWorkspaces,
    totalConfigs,
    activeConfigs,
    totalTrafficUsedBytes: (trafficAgg._sum.trafficUsedBytes || 0n).toString(),
    systemStatus: "operational",
  });
});

router.get("/users", async (req, res) => {
  const search = req.query.q ? String(req.query.q) : undefined;
  const users = await prisma.user.findMany({
    where: search ? { email: { contains: search, mode: "insensitive" } } : undefined,
    select: { id: true, email: true, name: true, role: true, status: true, createdAt: true, lastSeen: true, workspaceId: true },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  res.json({ users }); // هرگز passwordHash در پاسخ قرار نمی‌گیرد
});

router.get("/users/:id", async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: { id: true, email: true, name: true, role: true, status: true, createdAt: true, lastSeen: true, workspaceId: true },
  });
  if (!user) return res.status(404).json({ error: "کاربر یافت نشد" });
  const workspace = user.workspaceId
    ? await prisma.workspace.findUnique({
        where: { id: user.workspaceId },
        include: { _count: { select: { configs: true, configUsers: true, subscriptions: true } } },
      })
    : null;
  res.json({ user, workspace });
});

router.patch("/users/:id", async (req, res) => {
  const schema = z.object({ status: z.enum(["ACTIVE", "DISABLED"]).optional() });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "ورودی نامعتبر است" });

  const user = await prisma.user.update({
    where: { id: req.params.id },
    data: parsed.data,
    select: { id: true, email: true, status: true },
  });
  await logAudit({ userId: req.user.id, action: parsed.data.status === "DISABLED" ? "Admin Disabled User" : "Admin Enabled User", metadata: { targetUserId: user.id }, ip: req.ip });
  res.json({ user });
});

router.delete("/users/:id", async (req, res) => {
  await prisma.user.delete({ where: { id: req.params.id } }).catch(() => {});
  await logAudit({ userId: req.user.id, action: "Admin Deleted User", metadata: { targetUserId: req.params.id }, ip: req.ip });
  res.json({ ok: true });
});

router.get("/workspaces", async (req, res) => {
  const workspaces = await prisma.workspace.findMany({
    include: { _count: { select: { configs: true, users: true, configUsers: true } }, plan: true },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  res.json({ workspaces });
});

// --- مدیریت Plan ---
const planSchema = z.object({
  name: z.string().min(1),
  maxConfigs: z.coerce.number().int().positive(),
  maxUsers: z.coerce.number().int().positive(),
  trafficLimitGb: z.coerce.number().int().positive(),
  durationDays: z.coerce.number().int().positive(),
  features: z.array(z.string()).default([]),
});

router.get("/plans", async (req, res) => {
  const plans = await prisma.plan.findMany({ orderBy: { createdAt: "asc" } });
  res.json({ plans });
});

router.post("/plans", async (req, res) => {
  const parsed = planSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "ورودی نامعتبر است" });
  const plan = await prisma.plan.create({ data: parsed.data });
  res.status(201).json({ plan });
});

router.patch("/plans/:id", async (req, res) => {
  const parsed = planSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "ورودی نامعتبر است" });
  const plan = await prisma.plan.update({ where: { id: req.params.id }, data: parsed.data });
  res.json({ plan });
});

router.delete("/plans/:id", async (req, res) => {
  await prisma.plan.delete({ where: { id: req.params.id } }).catch(() => {});
  res.json({ ok: true });
});

// --- Site Settings ---
router.get("/settings", async (req, res) => {
  const rows = await prisma.systemSetting.findMany();
  const settings = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  res.json({ settings });
});

router.patch("/settings", async (req, res) => {
  const entries = Object.entries(req.body || {});
  for (const [key, value] of entries) {
    await prisma.systemSetting.upsert({ where: { key }, create: { key, value }, update: { value } });
  }
  res.json({ ok: true });
});

router.get("/health", async (req, res) => {
  const health = { backend: "ok", database: "unknown", cloudflareApi: "unknown" };
  try {
    await prisma.$queryRaw`SELECT 1`;
    health.database = "ok";
  } catch {
    health.database = "error";
  }
  try {
    const resp = await fetch("https://api.cloudflare.com/client/v4/ips");
    health.cloudflareApi = resp.ok ? "ok" : "error";
  } catch {
    health.cloudflareApi = "error";
  }
  res.json(health);
});

module.exports = router;
