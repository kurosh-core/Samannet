require("dotenv").config();
const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const cookieParser = require("cookie-parser");

const authRoutes = require("./routes/auth");
const configRoutes = require("./routes/configs");
const userRoutes = require("./routes/users");
const { authedRouter: subscriptionRoutes, publicRouter: publicSubscriptionRoutes } = require("./routes/subscriptions");
const statisticsRoutes = require("./routes/statistics");
const cloudflareRoutes = require("./routes/cloudflare");
const adminRoutes = require("./routes/admin");
const { requireAuth } = require("./middleware/auth");
const { startExpiryJob } = require("./lib/expiryJob");
const { publicSubLimiter } = require("./middleware/rateLimit");

const REQUIRED_ENV = ["DATABASE_URL", "SESSION_SECRET", "ENCRYPTION_KEY"];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    console.error(`[boot] متغیر محیطی ${key} تنظیم نشده است - لطفا فایل .env را بررسی کنید`);
    process.exit(1);
  }
}

const app = express();
app.set("trust proxy", 1);

app.use(
  helmet({
    contentSecurityPolicy: false, // برای سادگی فرانت‌اند inline؛ در تولید واقعی می‌توان سخت‌گیرانه‌تر کرد
  })
);
app.use(cors({ origin: process.env.APP_URL || true, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());

// مسیر عمومی Subscription - باید قبل از static و بدون نیاز به Auth باشد
app.use("/", publicSubLimiter, publicSubscriptionRoutes);

// API Routes (Modular)
app.use("/api/auth", authRoutes);
app.use("/api/configs", configRoutes);
app.use("/api/users", userRoutes);
app.use("/api/subscriptions", subscriptionRoutes);
app.use("/api/statistics", statisticsRoutes);
app.use("/api/cloudflare", cloudflareRoutes);
app.use("/api/admin", adminRoutes);

// فایل‌های استاتیک فرانت‌اند
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => res.redirect("/dashboard"));
app.get("/login", (req, res) => res.sendFile(path.join(__dirname, "public/login.html")));
app.get("/register", (req, res) => res.sendFile(path.join(__dirname, "public/register.html")));
app.get("/dashboard*", (req, res) => res.sendFile(path.join(__dirname, "public/dashboard.html")));
app.get("/admin*", (req, res) => res.sendFile(path.join(__dirname, "public/admin.html")));

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.use((req, res) => res.status(404).json({ error: "یافت نشد" }));

// Error handler سراسری - هرگز Stack Trace یا Secret به کاربر نمایش داده نمی‌شود
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("[error]", err.message);
  res.status(err.status || 500).json({ error: "خطای داخلی سرور رخ داده است" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Config Cloud Panel در حال اجرا روی پورت ${PORT}`);
  startExpiryJob();
});
